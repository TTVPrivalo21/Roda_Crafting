Config = {}

Config.CraftingPoints = {
    {
        coords = vector3(552.85, -2773.82, 6.09),
        gang = "sinaloa",
        categories = { "drogas" },
        radius = 2.0,
        label = "Mesa de Drogas", 
        icon = "fas fa-cogs"
    }
}