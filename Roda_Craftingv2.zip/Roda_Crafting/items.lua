Items = {
    ['drogas'] = {
        { name = "cock", cost = 7000, duration = 15000, count = 1 },
        { name = "packaged_weed", cost = 7000, duration = 15000, count = 1 }
    },
    ['armas'] = {
        { name = "weapon_pistol", cost = 9000, duration = 15000, count = 1, },
    },
}